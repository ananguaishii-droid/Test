# PROCYSIS

Roblox Multi-Screen Manager for Termux / Redfinger / Android

สคริปต์นี้ถูกแกะออกมาจากไฟล์ obfuscated ต้นฉบับ (base64 + gzip)

## วิธีใช้

```bash
bash procysis.sh
```

หรือให้สิทธิ์แล้วรัน:

```bash
chmod +x procysis.sh
./procysis.sh
```

## หมายเหตุ

- ใช้ root หรือ ADB ได้
- เก็บ cookie Roblox (.ROBLOSECURITY) ใน ~/procysis/cfg/
- แนะนำให้ใช้บัญชีรองเท่านั้น
